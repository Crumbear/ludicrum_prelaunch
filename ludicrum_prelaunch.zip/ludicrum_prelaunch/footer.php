<div id="splash-illustration" class="container-fluid"></div>
<div id="byline" class="container-fluid">
	<p class="text-center">Made with <i class="icon-heart"></i> by <a href="http://www.ludicrumedia.no">Ludicrumedia</a>. 2016 &copy; <a href="https://www.ludicrum.no">Ludicrum</a> <a href="mailto:hq@ludicrum.no"><i class="icon-mail"></i></a></p>
</div>

<?php wp_footer(); ?>
</body>
</html>
