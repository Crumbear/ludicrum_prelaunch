<?php
/* Fjern admin bar css */
add_action('get_header', 'remove_admin_login_header');
function remove_admin_login_header() {
	remove_action('wp_head', '_admin_bar_bump_cb');
}


/* Opprett funksjoner som inneholder stilark og script temaet skal laste inn */
function ludicrum_prelaunch_style_queue() {
	/* Legg foreldrestilarket i innlastingskøen */
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	/* Legg bootstrap i innlastingskøen */
	wp_enqueue_style( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' );
	/* Legg ikonfont i innlastingskøen */
	wp_enqueue_style( 'fontello', get_stylesheet_directory_uri() . '/fonts/fontello/css/fontello.css' );
    /* Legg child themets stilark i innlastingskøen */
	wp_enqueue_style( 'child-style',get_stylesheet_directory_uri() . '/style.css', array( $parent_style ));
}
function ludicrum_prelaunch_script_queue() {
	wp_enqueue_script( 'bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', false);
}
/* Knytt stilarkkøen og scriptkøen til WordPress' scriptinnlastingskø */
add_action( 'wp_enqueue_scripts', 'ludicrum_prelaunch_style_queue' );

/* Opprett menyområder */
function ludicrum_prelaunch_menus() {
  register_nav_menus(
    array(
      'main-menu' => __( 'Main Menu','ludicrum' ),
      'extra-menu' => __( 'Extra Menu','ludicrum' )
    )
  );
}
add_action( 'init', 'ludicrum_prelaunch_menus' );
?>