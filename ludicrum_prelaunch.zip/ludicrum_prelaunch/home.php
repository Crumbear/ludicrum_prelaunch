<?php
	get_header();

	?>
		<h1 class="text-center">Blogg</h1>
		<section class="container">
			<div class="row">
		<?php
		
		//First post. It's BIG!
		$first_post = get_posts('numberposts=1');
		
		if(has_post_thumbnail($first_post[0]->ID)) {
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( apply_filters( 'wpml_object_id', $article->ID, 'post' ) ), 'large' );
			$article_image = $image[0];
		} else {
			$article_image = get_stylesheet_directory_uri()."/img/default_blog-image.png";
		}
		echo "<article class='blog-item blog-front-item blog-item-first col-lg-8 col-md-8 col-sm-12 col-xs-12'>
			<img src='".$article_image."' class='blog-item-article-image' alt='".get_the_title($post->ID)."' />
			<a class='title-box' href='".get_permalink($first_post[0]->ID)."'>
				<h1>".get_the_title($first_post[0]->ID)."</h1>
				<span class='date'>".get_the_date('d.m.Y')."</span>
			</a>
		</article>";
		
		//Second and third post!
		echo "<div class='col-lg-4 col-md-4 col-sm-6 col-xs-12'>";
		$post23 = get_posts('numberposts=2&offset=1');
		
		foreach($post23 as $post) {
			if(has_post_thumbnail($post->ID)) {
				$image = wp_get_attachment_image_src( get_post_thumbnail_id( apply_filters( 'wpml_object_id', $article->ID, 'post' ) ), 'medium' );
				$article_image = $image[0];
			} else {
				$article_image = get_stylesheet_directory_uri()."/img/default_blog-image.png";
			}
			echo "<article class='blog-item blog-front-item blog-item-aside col-lg-12'>
				<img src='".$article_image."' class='blog-item-article-image' alt='".get_the_title($post->ID)."' />
				<h2><a href='".get_permalink($post->ID)."'>".get_the_title($post->ID)."</a></h2>
			</article>";
		}
		echo "</div>";
		?>
		
			</div>
			<div class="row">
				<?php
					$newest_posts = get_posts('numberposts=12&offset=3');
				?>
			</div>
		
		
		</section>
<?php
	/*while(have_posts()) : the_post();
		echo "<div class='row'><pre>";
		var_dump($post);
		echo "</pre></div>";
	endwhile;*/
	get_footer();
?>