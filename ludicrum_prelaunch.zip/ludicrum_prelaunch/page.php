<?php
	get_header();
?>
	<section class="container page-container">
		<div class="row">
			<div class="col-lg-8">
				<h1><?php the_title(); ?></h1>
				<?php echo the_content(); ?>
			</div>
		</div>
	</section>
<?php
	get_footer();
?>