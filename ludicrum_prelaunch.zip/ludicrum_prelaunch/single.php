<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<section class="container article-section">
	<div class="row">
	
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php
			while ( have_posts() ) : the_post();
			?>
				<div class="article-content row">
					<header class="col-lg-12">
						
						<h1 class='blog-title'><small><em>From the blog:</em></small><br /><?php echo get_the_title(); ?></h1>
					</header>
					<div class="article-main-content col-lg-8 col-md-8 col-sm-12 col-xs-12">
						<?php
						the_content();
						
						wp_link_pages( array(
							'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'ludicrum_prelaunch' ) . '</span>',
							'after'       => '</div>',
							'link_before' => '<span>',
							'link_after'  => '</span>',
							'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'ludicrum_prelaunch' ) . ' </span>%',
							'separator'   => '<span class="screen-reader-text">, </span>',
						) );
						?>
					</div>
					<aside class="col-lg-4 col-sm-12">
						<div class="article-meta-box ">
							<i class='icon-calendar'></i> <?php echo get_the_date('d.m.Y, H:i'); ?>
						</div>
						<div class="article-meta-box">
							<i class="icon-folder"></i> <?php 
								$categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'ludicrum_prelaunch' ) );
								if ( $categories_list && twentysixteen_categorized_blog() ) {
									printf( '<span class="sr-only">%1$s </span>%2$s',
										_x( 'Categories', 'Used before category names.', 'ludicrum_prelaunch' ),
										$categories_list
									);
								}
							?>
						</div>
						<div class="article-meta-box">
							<i class="icon-tags"></i> <?php 
								$tags_list = get_the_tag_list( '', _x( ', ', 'Used between list items, there is a space after the comma.', 'ludicrum_prelaunch' ) );
								if ( $tags_list ) {
									printf( '<span class="sr-only">%1$s </span>%2$s',
										_x( 'Tags', 'Used before tag names.', 'ludicrum_prelaunch' ),
										$tags_list
									);
								}
							?>
						</div>
						<div class="article-meta-box">
							<i class="icon-comment"></i><a href="#comments"><?php comments_number(); ?></a>
						</div>
					</aside>
					<div class="article-comments">
						<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) {
							comments_template();
						}
						?>
					</div>
				</div>
				
				<?php
			endwhile;
			?>
		</article>
		
	</div>
</section>

<?php get_footer(); ?>
