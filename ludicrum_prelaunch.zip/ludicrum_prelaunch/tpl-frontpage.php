<?php
/*
 * Template name: Frontpage
 */
 
 get_header();
 ?>
<div id="splash" class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h1><?php the_title(); ?></h1>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-7 col-sm-12">
				<?php the_content(); ?>
			</div>
			<div class="col-lg-5 col-sm-12 mailform">
				<!-- Begin MailChimp Signup Form -->
				<div id="mc_embed_signup">
					<form id="mc-embedded-subscribe-form" class="validate" action="//ludicrum.us14.list-manage.com/subscribe/post?u=82c5f33f47c670743860ee52f&amp;id=d251746a7d" method="post" name="mc-embedded-subscribe-form" novalidate="" target="_blank">
					<div id="mc_embed_signup_scroll">
						<div class="mc-field-group form-group">
							<label for="mce-EMAIL">E-postadresse <span class="asterisk">*</span></label>
							<input id="mce-EMAIL" class="form-control required email" name="EMAIL" type="email" value="" />
						</div>
						<div class="mc-field-group form-group">
							<label for="mce-FNAME">Fornavn</label>
							<input id="mce-FNAME" class="form-control" name="FNAME" type="text" value="" />
						</div>
						<div class="mc-field-group form-group">
							<label for="mce-LNAME">Etternavn</label>
							<input id="mce-LNAME" class="form-control" name="LNAME" type="text" value="" />
						</div>
						
						<div id="mce-responses" class="clear"></div>
					
						<div class="row">
							<!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
							<div style="position: absolute; left: -5000px;"><input tabindex="-1" name="b_82c5f33f47c670743860ee52f_d251746a7d" type="text" value="" /></div>
							<div class="col-lg-6 col-sm-12"><input id="mc-embedded-subscribe" class="btn btn-success" name="subscribe" type="submit" value="Registrer" /></div>
							<div class="indicates-required col-lg-6 col-sm-12"><small><span class="asterisk">*</span>Indikerer påkrevd felt</small></div>
						</div>
					</div>
					<p><small>E-postadressen du registrerer her vil bli brukt for kommunikasjon med Ludicrum, invitasjoner til spørreundersøkelser og Early Bird-acces: tilbud om unike produkter før de blir tilgjengelig i nettbutikken. Ved å melde deg på som en Ludicrum Builder via skjemaet på denne siden, godtar du dette.</small></p>
					</form>
				</div>
				<!--End mc_embed_signup-->
			</div>
		</div>	
	</div>
</div>

<?php
get_footer();
?>